// Exports the "dom" model for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/models/dom')
//   ES2015:
//     import 'tinymce/models/dom'
require('./model.js');